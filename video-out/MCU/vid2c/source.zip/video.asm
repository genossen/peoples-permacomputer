;/******************************************************************************/
;/  Composite Video Display generator											/
;/  (40x25 monochrome text generation)	 										/
;/  SPI/raw serial input with handshake  										/
;/																				/
;/  Designed and written by Daryl Rictor (c)2014   								/ 
;/******************************************************************************/

;******************************************************************************
; Fuse Settings
;******************************************************************************
; Extd = 0xf9
; High = 0xdf
; Low  = 0xc0
;
; Compiled using AVR Studio V4.19 with Version 2 assembler
;
;******************************************************************************
; include ATMega88PA definitions & program specific definitions and macros
;******************************************************************************
.include  "m88PAdef.inc"
.include  "defs.inc"
;******************************************************************************
; Code Begins at 0x000
; System IRQ jump table from 0x0000 - 0x0019
;******************************************************************************
	rjmp	RESET				; External Reset
	rjmp	INT0V				; External Interrupt Request 0
	rjmp	INT1V				; External Interrupt Request 1
	rjmp	PCINT0V				; Pin Change Interrupt Request 0
	rjmp	PCINT1V				; Pin Change Interrupt Request 1
	rjmp	PCINT2V				; Pin Change Interrupt Request 2
	rjmp	WDT					; Watchdog Time-out Interrupt
	rjmp	TIMER2_COMPA		; Timer/Counter2 Compare Match A
	rjmp	TIMER2_COMPB		; Timer/Counter2 Compare Match B
	rjmp	TIMER2_OVF			; Timer/Counter2 Overflow
	rjmp	TIMER1_CAPT			; Timer/Counter1 Capture Event
	rjmp	TIMER1_COMPA		; Timer/Counter1 Compare Match A
	rjmp	TIMER1_COMPB		; Timer/Counter1 Compare Match B
	rjmp	TIMER1_OVF			; Timer/Counter1 Overflow
	rjmp	TIMER0_COMPA		; Timer/Counter0 Compare Match A
	rjmp	TIMER0_COMPB		; Timer/Counter0 Compare match B
	rjmp	TIMER0_OVF			; Timer/Counter0 Overflow
	rjmp	SPI_STC				; SPI Serial Transfer Complete
	rjmp	USART0_RX			; USART0 Rx Complete
	rjmp	USART0_UDRE			; USART0 Data Register Empty
	rjmp	USART0_TX			; USART0 Tx Complete
	rjmp	ADCC				; ADC Conversion Complete
	rjmp	EE_READY			; EEPROM Ready
	rjmp	ANALOG_COMP			; Analog Comparator
	rjmp	TWI					; 2-wire Serial Interface
	rjmp	SPM_READY			; Store Program Memory Ready
	
;******************************************************************************
; unused IRQ vector's point to software reset code
;******************************************************************************
INT0V:							; External Interrupt Request 0
INT1V:							; External Interrupt Request 1
PCINT0V:						; Pin Change Interrupt Request 0
PCINT1V:						; Pin Change Interrupt Request 1
PCINT2V:						; Pin Change Interrupt Request 2
WDT:							; Watchdog Time-out Interrupt
TIMER2_COMPA:					; Timer/Counter2 Compare Match A
TIMER2_COMPB:					; Timer/Counter2 Compare Match B
TIMER2_OVF:						; Timer/Counter2 Overflow
TIMER1_CAPT:					; Timer/Counter1 Capture Event
;TIMER1_COMPA:					; Timer/Counter1 Compare Match A
;TIMER1_COMPB:					; Timer/Counter1 Compare Match B
TIMER1_OVF:						; Timer/Counter1 Overflow
TIMER0_COMPA:					; Timer/Counter0 Compare Match A
TIMER0_COMPB:					; Timer/Counter0 Compare match B
TIMER0_OVF:						; Timer/Counter0 Overflow
SPI_STC:						; SPI Serial Transfer Complete
USART0_RX:						; USART0 Rx Complete
USART0_UDRE:					; USART0 Data Register Empty
USART0_TX:						; USART0 Tx Complete
ADCC: 							; ADC Conversion Complete
EE_READY:						; EEPROM Ready
ANALOG_COMP:					; Analog Comparator
TWI:							; 2-wire Serial Interface
SPM_READY:						; Store Program Memory Ready
	
;******************************************************************************
; Program Starts here on Reset
;******************************************************************************
RESET:							; first line executed after reset 
	CLI							; disable interupts

;******************************************************************************
; Initialize the I/O Ports
;******************************************************************************
; port B pins (video control/SPI)
	LDI		i, 0x02				; 
	out		portb, i			; set Port B pins 0,2 - 7 no pullups, 1 output high
	LDI		i, 0x02				; PB1 = handshake 
	out		ddrb, i				; set DDRB pin PB1 to output

; port C pins (video data bus - pc0-pc3, pc4-pc7 unconnected for speed)
	ldi		i, 0x20				; Pullups On for PC5
	out		portc, i			; set port c outputs to 0x3F
	LDI		i, 0x00				; pins 0 - 5 of port c
	out		ddrc, i				; set DDRC pins 0 - 5 to inputs

; port D pins
	ldi		i, 0x00				; Pullups Off for PD0-PC7
	out		portd, i			; set port d outputs to 0
	LDI		i, 0x04				; pin PD2 - video out
	out		ddrd, i				; set DDRC pin 2 to output

;******************************************************************************
; Init other CPU I/O registers
;******************************************************************************
	ldi     i, 0x80
	out     ACSR, i				; turn off comparator

	ldi     i, 0x01
	out		SMCR, i				; enable sleep mode

	ldi		i, 0x04				; set stack pointer to top of SRAM 
	out		SPH, i				;
	ldi		i, 0xff				; 
	out		SPL, i				;

;******************************************************************************
; Initialize the Display SRAM
;******************************************************************************
InitRAM:
; fill display SRAM with the Startup Banner 
	ldi		ZL, 0x00
	ldi		ZH, 0x0C			; set to start of Banner in Prog Mem
	ldi		YL, 0x00
	ldi		YH, 0x01			; set to start of SRAM
	ldi		XL, 0xE8
	ldi		XH,	0x03			; set X to 1000
frloop:
	lpm		i, Z+				; get banner image
	st 		Y+, i				; save to SRAM			
	sbiw	XL, 1				; dec X
	brne	frloop				; do until X=0

;******************************************************************************
; Initialize Program Variables
;******************************************************************************

;text gen initialization
	ldi		hpos, 0x00			; leftmost horizontal chr pos 0 (0-39)
	ldi		vpos, 0x17			; vertical chr pos 23 (0-24)
	ldi		Cursclk, 0x00		; init cursor blink timer
	ldi		Cursctl, 0x5F		; init cursor '_' character
	ldi		i,	0x00			; 0
	mov		fnthl, i			; set high/low flag to low
	mov		fntsel, i			; set Font to primary
	ldi		yh, 0x04			;
	ldi		yl, 0x98			; point to line 23, col 0 for cursor
	ld		Curschr, Y			; init cursor character

;******************************************************************************
;  Init SER (65C22 shift register mode)
;******************************************************************************
Init_SER:
	sbi		ddrb, pb4			; Set MISO ouput (not used)
	sbi		ddrb, hsp			; mark not ready for data
	sbi		portb, hsp			; mark not ready for data
	ldi 	i, (1<<SPE)|(1<<CPHA)|(1<<CPOL)		; Enable SPI, Slave Mode, mode 3
	out 	SPCR, i

;******************************************************************************
; Initial Counter 0 for handshake timing
;******************************************************************************
	ldi		i, 0x00
	out		tccr0a, i			; normal port operations
	ldi		i, 0x01	
	out		tccr0b, i			; clk div = 1
	ldi		i, 0x83	
	out		ocr0a, i			; set match to 128 (8uS) (+3 b/c reset to 0x03)
	ldi		i, 0x00
	sts		timsk0, i			; no interrupts

;******************************************************************************
; Select PAL/NTSC System
;******************************************************************************
	cbi		ddrc, pc5			; PC5 set for input
	sbi		portc, pc5			; add pull up resistor to pin C5
	nop							; delay (wait for pull up resistor...)
	nop							; ""
	nop							; ""
	nop							; delay (if PAL not is selected...) 
	nop							; ""
	nop							; ""
	nop							; delay (to raise this line high)
	nop							; ""
	nop							; ""
	nop							; delay 
	nop							; ""
	nop							; ""
	nop							; delay 
	nop							; ""
	nop							; ""
	sbis	pinc, pc5			; is Pin C5 low?
	rjmp	PALInit				; Yes, set PAL mode

NTSCInit:
	ldi		i, 0xF8
	ldi		j, 0x03
	movw	scanln, i			; 03F8
	ldi		i, 0xD6				
	mov		vend, i				; 03D6
	ldi		i, 0xE9
	mov		scanend, i			; 03E9
	ldi		i, 0x9C
	mov		left, i				; 009C
	ldi		i, 0x28
	mov		top, i				; 0028
	ldi		i, 0x06				
	mov		numlines, i			; 0106
	rjmp	InitCOMP

PALInit:
	ldi		i, 0x00
	ldi		j, 0x04
	movw	scanln, i			; 0400
	ldi		i, 0xD7				
	mov		vend, i				; 03D7
	ldi		i, 0xEA
	mov		scanend, i			; 03EA
	ldi		i, 0x92
	mov		left, i				; 0092
	ldi		i, 0x30
	mov		top, i				; 0030
	ldi		i, 0x38				
	mov		numlines, i			; 0138
	rjmp	InitCOMP

;******************************************************************************
; Init Comp video 
;******************************************************************************
InitCOMP:
; Init USART and sync port
	sbi		ddrd, syncpin		; sync port
	sbi		portd, syncpin

	sbi		ddrd, pd1			; data port
	cbi		portd, pd1

	ldi		i, 0x00				; USART0 will be video data shift register
	sts		UBRR0H, i
	sts		UBRR0L, i			; baud rate to 0 (1/2 Fclk)

	sbi		ddrd, pd4			; xclk to output (not used but must be done)
	
	ldi 	i, (1<<UMSEL01)|(1<<UMSEL00)|(1<<UCPHA0)|(1<<UCPOL0)
	sts 	UCSR0C, i			; Enable USART in SPI mode

	ldi 	i, (0<<RXEN0)|(1<<TXEN0)	; Enable transmitter.
	sts 	UCSR0B,	i
	ldi		i, 0x00
	sts		udr0, i				; shift out 0x00 to clear video pin

	ldi		i, 0x00				; set baud rate again (required)
	sts		UBRR0H, i
	sts		UBRR0L, i			; baud rate to 0 or 1 (1/2 or 1/4 Fclk)

; Init timer 1 for refresh operation
	ldi     i, 0x00
	sts    	TCCR1A, i
	ldi     i, 0x09				; set timer 1 to CTC mode 4
	sts     TCCR1B, i		

	sts     OCR1AH, scanlnh    	; 
	sts     OCR1AL, scanln		; counter range

	ldi		j, 0x03				; 
	sts     OCR1BH, j        	; 
	sts     OCR1BL, vend		; VSYNC IRQ

	clr		vline
	clr		vlineh				; set line counter to  (top)

	ldi     i, 0x00				; clear timer 1
	sts     TCNT1H, i			; 
	sts     TCNT1L, i			; 
	ldi		i, 0x07				; clear timer 1 IRQ's
	out		TIFR1, i			; clear timer 1 IRQ's

	ldi     i, 0x06				; allow OCR1A & OCR1B IRQ's
	sts     TIMSK1, i			

Ready:
; Ready to go
	SEI							; enable system IRQ's - GO!!!
BANNER:
	cpi		CursClk, 0xFF		; 
	brne	Banner				; 
	clr		Cursclk				; reset to 0 for blink mode
	cbi		portb, hsp			; mark ready for data
;##############################################################################
;#																			  #
;#  Main Loop 																  #	
;#																			  #
;##############################################################################
Main:
	cpi		Cursctl, 0x00		; is the cursor turned on?
	breq	main2				; no, skip control code
	cpi		Cursclk, 0xff		; is clk at 0xFF?
	breq	main1				; yes - solid cursor (no blink)
	cpi		Cursclk, 0x1C		; is it above 28 frames?
	brpl	main2				; if >28, show Cursor
	st		Y, Curschr			; if clr, show character
	rjmp	main3				; 
main1:
	st		Y, Cursctl			; if set show cursor
	rjmp	main3
main2:
	st		Y, Cursctl			; if set show cursor
	cpi		Cursclk, 0x37		; is it >56 
	brmi	main3				; no
	clr		Cursclk				; reset timer
main3:

    in      i, SPSR             ; get shift register status
    sbrs    i, SPIF             ; Wait for reception complete
    rjmp    Main
    st      Y, Curschr          ; restore chr under cursor
    in      inpt, SPDR          ; Read received data
; on the older ATMega8 you need to replace the SBI pinx with the next 4 lines
    in      i,portb             ; Toggle busy -> idle (SPDR available)
    ldi     j,(1<<hsp)
    eor     i,j
    out     portb,i
    rcall   ProcChr             ; process received data
    rjmp    Main                ; repeat


;SERIN1:
;	in		i, SPSR				; get shift register status
;	sbrs 	i, SPIF				; Wait for reception complete
;	rjmp 	Main
;	sbi		portb, hsp			; mark not ready for data
;	ldi		i, 0x03
;	out		tcnt0, i			; counter 0 used for handshake minimum timer
;	out		tifr0, i			; reset ocr0a flag
;	st		Y, Curschr			; restore chr under cursor
;	in 		inpt, SPDR			; Read received data
;	rcall	ProcChr				; process received data
;main4:
;	in		i, tifr0			; read timer 0 flags
;	sbrs	i, OCF0A			; compare A > 128? (8uS)
;	rjmp	main4
;	cbi		portb, hsp			; mark ready for data
;	rjmp	Main				; repeat

;******************************************************************************
; IRQ Service Routines
;******************************************************************************
;
; Timer 1 for composite video
;
TIMER1_COMPA:
	.include "VidGen.asm"		; file that holds the video generation code	
	reti						; done

TIMER1_COMPB:
	in		savsr, SREG			; save the status register
	sbi		portd, syncpin		; raise the sync pin (its low during VSYNC, else no effect)
	sei							; enable IRQ before we sleep so OCR1A can work
	sleep						; wait for TIM1_COMPA IRQ
	out		SREG, savsr			; restore the status register
	reti						; all done, go back to Main Prgm

;******************************************************************************
; include subroutines and Constant Data tables
;******************************************************************************
.include "ProcChr.inc"			; handler for USART Input
.include "banner.inc"

; you can select any two fonts - the first will be the prime font, second one is alternate
.CSEG
.ORG 0x800
;.include "primfont.inc"			; disp PRIMARY font 0x800-0xBFF
;.include "altfont.inc"			; disp ALT font 0xC00-0xFFF


; C64 and pet fonts include both sets in 1 file
; Apple font is just the prime, use the default prime or alt font for the second half

;.include "c64font.inc"			; c-64 fonts c64afont & c64bfont
;.include "petfont.inc"			; pet fonts petafont & petbfont
.include "appfont.inc"			; Apple 2 Font (not verified)
.include "altfont.inc"			; disp ALT font 0xC00-0xFFF

;******************************************************************************
; End of Program
;******************************************************************************
