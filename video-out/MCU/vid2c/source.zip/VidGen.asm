;
; Composite Video Refresh Generator
; written by Daryl Rictor
;
; supports NTSC (tested) and PAL (untested)
;
	CLI							;
	cbi		portd, syncpin		; 2  drop sync

	movw	svacc, acc			; save R0/1 & R30/31
	movw	svz, zl

	adiw	vline, 0x01			; 2     increment line counter
	cpi		vlineh, 0x01		; 1     >256?
	brne	ref1				; 1/2   no
	cp		vline, numlines		; 1     are we at the last line?
	brne	blank1				; 1/2	no
	clr		vline				; 1     yes - reset to 0 
	clr		vlineh				; 1
	rjmp	vsync				; 2     do a v sync line
ref1:
	cpi		vline, 0x03			; 1		3 lines of vsync
	brcs	vsync				; 1/2

	cp		vline, top			; 1     ready for first row?
	brcs	blank				; 1/2   no - do blank line

	ldi		xl, 0xC8			; 1     200 lines (25 rows x 8pixels high)?
	add		xl, top				; 1     add offset from top
	cp		vline, xl			; 1		at 200 yet?
	brcs	active				; 1/2   no - generate line of data
	rjmp	blank				; 2     yes (entry for > last line < 256)
blank1:
	nop							; 1     gen blank line (entry for > 255)
	nop							; 1
	nop							; 1     timing adjust...
blank:
	ldi		xh, 0x03			; 1
	sts     OCR1BH, xh     		; 2
	sts     OCR1BL, scanend		; 2     set end of line for next refresh
	ldi		xh, 0x4D			; 1     hsync timing 4.7uS
blanklp:
	lds		xl, tcnt1l			; 2
	cp		xl, xh				; 1     (sync end)?
	brcs	blanklp				; 1/2   not yet
	nop							; 1
	lpm		acc, Z				; 3     nop
	nop							; 1     timing adjust
	sbi		portd, syncpin		; 2     raise sync (end of hsync)
	rjmp	end					; 2     done

vsync:
	ldi		xh, 0x03
	sts     OCR1BH, xh     		; 2
	sts     OCR1BL, vend		; 2     set vsync line timing 

	cpi		Cursclk, 0xff		; 
	breq	vs1					;
	inc		Cursclk				;       inc cursor clock
vs1:
	rjmp	end					; 2     done

active:
	lds		xl, tcnt1l			; 2
	cpi		xl, 0x4E			; 1     (sync end)
	brcs	active				; 1/2
	nop							; 1
	sbi		portd, syncpin		; 2     end of hsync pulse

;nop's

active1:
	lds		xl, tcnt1l			; 2
	cp		xl, left			; 1 (left edge)
	brcs	active1				; 1/2   wait for left edge start time

	mov		xl, vline           ; 1   
	ldi		xh, 0x28			; 1     40 bytes per line
	sub		xl, top				; 1     calc # lines from top 
	mov		zh, xl				; 1     save for font table use
	lsr		xl					; 1 
	lsr		xl					; 1
	lsr		xl					; 1     divide by 8
	mul		xl, xh				; 2     * 40 bytes
	inc		acch				; 1     offset RAM

	ldi		xh, 0x00
	ldi 	xl, (0<<RXEN0)|(1<<TXEN0);  1 start pixel shift register
	sts		udr0, xh			; 2     send to SPI
	sts 	ucsr0b,	xl			; 2     turn on txmtr
	sts		udr0, xh			; 2     send 0 to SPI
; a vertical line gets plotted here, but its still off screen on the left edge
; I add some delays below to move the display away from the left edge

	movw	xl, acc				; 1     char pointer set in X
	ldi		zl, 0x28			; 1     40 bytes to shift
	mov		acch, zl			; 1     for loop counter below
	ldi		ZL, 0x00			; 1     ZL=0, ASCII code will be added for each character
	andi	ZH, 0x07			; 1     do ZH MOD 8
	ori		ZH, 0x10			; 1     add $1000 for offset to start of font table
	or		ZH, fntsel			; 1     adjust for primary/alt font
	lpm		acc, Z				; 3     nop
	lpm		acc, Z				; 3     nop
	lds		acc, ucsr0a			; 2     read SPI status 
	clr		acc					; 1
	sts		udr0, acc			; 2     write more 0's to pixel register
	lpm		acc, Z				; 3     nop
	lpm		acc, Z				; 3     nop
	lpm		acc, Z				; 3     nop
	nop							; 1
	nop							; 1
	lds		acc, ucsr0a			; 2     read SPI status 
	clr		acc					; 1
	sts		udr0, acc			; 2     write another 0 pixel
	lpm		acc, Z				; 3     nop
	lpm		acc, Z				; 3     nop
	nop							; 1

BUILDSCREEN:
	lds		acc, ucsr0a			; 2     read SPI status 
	nop							; 1
	lpm		acc, Z				; 3     nop

	ld 		ZL, X+				; 2     move curr chr in ZL
	lpm 	acc, Z				; 3     get font byte for current chr on curr line
	sts		udr0, acc			; 2     write 8 pixels

	dec		acch				; 1	    loop counter
	brne	BUILDSCREEN			; 2     this loop is exactly 16 clock cycles between pixel writes

	ldi		xl, 0x00			; done, just clean things up     
	sts		udr0, xl			; write 0 pixel 
	sts 	UCSR0B,	xl			; turn off shift register

end:
	movw	acc, svacc			; restore R0/1 and R30/31
	movw	zl, svz				; RTI is located in main program	
