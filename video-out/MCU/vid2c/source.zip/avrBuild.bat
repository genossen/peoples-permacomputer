@ECHO OFF
"C:\Program Files\Atmel\AVR Tools\AvrAssembler2\avrasm2.exe" -S "C:\Users\Daryl\Desktop\vid2c\Source2\labels.tmp" -fI -W+ie -C V2E -o "C:\Users\Daryl\Desktop\vid2c\Source2\Video.hex" -d "C:\Users\Daryl\Desktop\vid2c\Source2\Video.obj" -e "C:\Users\Daryl\Desktop\vid2c\Source2\Video.eep" -m "C:\Users\Daryl\Desktop\vid2c\Source2\Video.map" "C:\Users\Daryl\Desktop\vid2c\Source2\video.asm"
