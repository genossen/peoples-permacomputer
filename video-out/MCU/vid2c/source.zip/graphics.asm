;
; Graphic drawing routines
; By Daryl Rictor
;
clscn:
	ldi		YL, low(vidbase)
	ldi		YH, high(vidbase)	; set to start of display SRAM
	ldi		ZL, 0x80
	ldi		ZH,	0x25			; set X to 9600
	ldi		i,	0x00			; data value
clscn1:
	st 		Y+, i				; save to SRAM			
	st 		Y+, i				; save to SRAM			
	st 		Y+, i				; save to SRAM			
	st 		Y+, i				; save to SRAM			
	st 		Y+, i				; save to SRAM			
	st 		Y+, i				; save to SRAM			
	st 		Y+, i				; save to SRAM			
	st 		Y+, i				; save to SRAM			
	sbiw	ZL, 8				; dec X
	brne	clscn1				; do until X=0
	ret

pset:
	ldi		i, 0xF0				; 240 y max
	cp		p1y, i
	brcc	pset2				; if >=240, exit
	tst		p1xh
	breq	pset1
	ldi		i, 0x40				; >=320 (0x140) exit
	cp		p1x, i
	brcc	pset2
pset1:
	mov		i, p1x	
	andi	i, 0x07				; mask bit position
	ldi		zl, low(bstable*2)
	ldi		zh, high(bstable*2)
	add		zl, i
	clr		i
	adc		zh, i
	movw	i, p1x				; non-destructive on p1x&p1y
	lsr		j
	ror		i
	lsr		i
	lsr		i					; px /8 to get byte pos on row
	mul		p1y, c40			; y*40 bytes per row
	add		acc, i				; add px offset
	ldi		i, 0x01
	adc		acch, i
	lpm		j, Z				; load bit mask
	movw	ZL, acc
	ld		i, Z				; read video ram
	or		i, j				; OR mask
	st		Z, i				; save it
pset2:
	ret

pclr:
	ldi		i, 0xF0
	cp		p1y, i
	brcc	pclr2
	tst		p1xh
	breq	pclr1
	ldi		i, 0x40				; >=320 (0x140) exit
	cp		p1x, i
	brcc	pclr2
pclr1:
	mov		i, p1x	
	andi	i, 0x07
	ldi		zl, low(bctable*2)
	ldi		zh, high(bctable*2)
	add		zl, i
	clr		i
	adc		zh, i
	movw	i, p1x
	lsr		j
	ror		i
	lsr		i
	lsr		i
	mul		p1y, c40
	add		acc, i
	ldi		i, 0x01				; start of video ram
	adc		acch, i
	lpm		j, Z
	movw	ZL, acc
	ld		i, Z
	and		i, j
	st		Z, i
pclr2:
	ret

pline: ; plot line from p1 to p2
pl1:
	cp		p1y, p2y
	breq	horz
	cp		p1xh, p2xh
	brne	pl2
	cp		p1x, p2x
	brne	pl2

vert:
	cp		p1y, p2y
	brcs	vert1
	mov		acc, p1y
	mov		p1y, p2y
	mov		p2y, acc
vert1:
	call	pset
	inc		p1y
	cp		p1y, p2y
	brne	vert1
	call	pset
	ret

horz:
	movw	ACC, p1x
	sub		acc, p2x
	sbc		acch, p2xh
	brcs    horz1
	movw	acc, p1x	
	movw	p1x, p2x
	movw	p2x, acc
horz1:
	call	pset
	inc		p1x
	brne	horz2
	inc		p1xh
horz2:
	cp		p1xh, p2xh
	brne	horz1
	cp		p1x, p2x
	brne	horz1
	call	pset
	ret

pl2:
	movw	ACC, p1x
	sub		acc, p2x
	sbc		acch, p2xh
	brcs    pl3
	movw	acc, p2x  			; swap points
    movw	p2x, p1x
	movw	p1x, acc
	mov		acc, p1y
	mov		p1y, p2y
	mov		p2y, acc
	rjmp	pl2					; recalc distance

pl3:
	clt	
	clr		px
	clr		py
	lsr		acch
	mov		acc, p1y
	sub		acc, p2y
	brcc	lneg
    lsr     acc
pl4:
	brtc	p144
	push	acc
	push	acch
	call	pset
	pop		acch
	pop		acc
	clt	
p144:
	add		px, acch
	brcc	pl5
	set	
	inc		p1x
	brne	pl5
	inc		p1xh
pl5:
	add		py, acc
	brcc	pl6
	set
	inc		p1y
pl6:
	cp		p1xh, p2xh
	brne	pl4
	cp		p1x, p2x
	brne	pl4
	call	pset
	ret

lneg:
    lsr     acc
lneg1:
	brtc	lneg2
	push	acc
	push	acch
	call	pset
	pop		acch
	pop		acc
	clt
lneg2:
	add		px, acch
	brcc	pl7
	set
	inc		p1x
	brne	pl7
	inc		p1xh
pl7:
	sub		py, acc
	brcs	pl8
	set
	dec		p1y
pl8:
	cp		p1xh, p2xh
	brne	lneg1
	cp		p1x, p2x
	brne	lneg1
	call	pset
	ret

cline: ; unplot line from p1 to p2
cl1:
	cp		p1y, p2y
	breq	chorz
	cp		p1xh, p2xh
	brne	cl2
	cp		p1x, p2x
	brne	cl2

cvert:
	cp		p1y, p2y
	brcs	cvert1
	mov		acc, p1y
	mov		p1y, p2y
	mov		p2y, acc
cvert1:
	call	pclr
	inc		p1y
	cp		p1y, p2y
	brne	cvert1
	call	pclr
	ret

chorz:
	movw	ACC, p1x
	sub		acc, p2x
	sbc		acch, p2xh
	brcs    chorz1
	movw	acc, p1x	
	movw	p1x, p2x
	movw	p2x, acc
chorz1:
	call	pclr
	inc		p1x
	brne	chorz2
	inc		p1xh
chorz2:
	cp		p1xh, p2xh
	brne	chorz1
	cp		p1x, p2x
	brne	chorz1
	call	pclr
	ret

cl2:
	movw	ACC, p1x
	sub		acc, p2x
	sbc		acch, p2xh
	brcs    cl3
	movw	acc, p2x   			; swap points
    movw	p2x, p1x
	movw	p1x, acc
	mov		acc, p1y
	mov		p1y, p2y
	mov		p2y, acc
	rjmp	cl2					; recalc distance

cl3:
	clr		px
	clr		py
	lsr		acch
	ror		acc
	mov		acc, p1y
	sub		acc, p2y
	brcc	clneg
cl4:
	push	acc
	push	acch
	call	pclr
	pop		acch
	pop		acc
	add		px, acch
	brcc	cl5
	inc		p1x
	brne	cl5
	inc		p1xh
cl5:
	add		py, acc
	brcc	cl6
	inc		p1y
cl6:
	cp		p1xh, p2xh
	brne	cl4
	cp		p1x, p2x
	brne	cl4
	call	pclr
	ret

clneg:
	push	acc
	push	acch
	call	pclr
	pop		acch
	pop		acc
	add		px, acch
	brcc	cl7
	inc		p1x
	brne	cl7
	inc		p1xh
cl7:
	sub		py, acc
	brcs	cl8
	dec		p1y
cl8:
	cp		p1xh, p2xh
	brne	clneg
	cp		p1x, p2x
	brne	clneg
	call	pclr
	ret

pbox:
	sts		r2s, p1x
	sts		r3s, p1xh
	sts		r4s, p1y
	sts		r6s, p2x
	sts		r7s, p2xh
	sts		r5s, p2y

	movw	p2x, p1x
	call	vert				; p1x,p1y - p1x,p2y

	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	lds		p2x, r6s
	lds		p2xh, r7s
	mov		p2y, p1y
	call	horz				; p1x, p1y - p2x, p1y

	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r5s
	lds		p2x, r6s
	lds		p2xh, r7s
	mov		p2y, p1y
	call	horz				; p1x, p2y - p2x, p2y
	
	lds		p1x, r6s
	lds		p1xh, r7s
	lds		p1y, r4s
	lds		p2y, r5s
	movw	p2x, p1x
	call	vert				; p2x, p1y - p2x, p2y
	ret


cbox:  ; clear a box
	sts		r2s, p1x
	sts		r3s, p1xh
	sts		r4s, p1y
	sts		r6s, p2x
	sts		r7s, p2xh
	sts		r5s, p2y

	movw	p2x, p1x
	call	cvert				; p1x,p1y - p1x,p2y

	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	lds		p2x, r6s
	lds		p2xh, r7s
	mov		p2y, p1y
	call	chorz				; p1x, p1y - p2x, p1y

	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r5s
	lds		p2x, r6s
	lds		p2xh, r7s
	mov		p2y, p1y
	call	chorz				; p1x, p2y - p2x, p2y
	
	lds		p1x, r6s
	lds		p1xh, r7s
	lds		p1y, r4s
	lds		p2y, r5s
	movw	p2x, p1x
	call	cvert				; p2x, p1y - p2x, p2y
	ret

pbar:	; filled box

	ldi		i, 0xff
	movw	acc, p1x
	sub		acc, p2x
	sbc		acch, p2xh
	brcc	pbr10
	eor		acc, i
	eor		acch, i
	inc		acc
	brne	pbr10
	inc		acch
pbr10:
	mov		py, p1y 
	sub		py, p2y
	brcc	pbr11
	eor		py, i
	inc		py
pbr11:	
	ldi		i, 0x00
	sub		acc, py
	sbc		acch, i

	brcs	pbr20				; optimize using vertical lines

	cp		p1y, p2y			; optimize using horizontal lines
	brcc	pbr12
	mov		py, p1y
	mov		px, p2y
	jmp		pbr2
pbr12:
	mov		py, p2y
	mov		px, p1y

pbr2:
	cp		p1x, p2x
	cpc		p1xh, p2xh
	brcc	pbr3

	sts		r2s, p1x
	sts		r3s, p1xh
	sts		r6s, p2x
	sts		r7s, p2xh
	jmp		pbr4
pbr3:
	sts		r2s, p2x
	sts		r3s, p2xh
	sts		r6s, p1x
	sts		r7s, p1xh
pbr4:
	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p2x, r6s
	lds		p2xh, r7s
	mov		p1y, py
	mov		p2y, py
	call	horz1
	inc		py
	cp		px, py
	brcc	pbr4
	ret

pbr20:
	sts		r4s, p1y
	sts		r5s, p2y

	cp		p1x, p2x
	cpc		p1xh, p2xh
	brcc	pbr21

	sts		r6s, p2x
	sts		r7s, p2xh
	movw	px, p1x
	jmp		pbr22

pbr21:
	sts		r6s, p1x
	sts		r7s, p1xh
	movw	px, p2x

pbr22:
	cp		p1y, p2y
	brcc	pbr23
	lds		p1y, r5s
	lds		p2y, r4s
pbr23:
	movw	p1x, px
	movw	p2x, px
	lds		p1y, r4s
	lds		p2y, r5s
	call	vert1
	inc		px
	brne	pbr24
	inc		py
pbr24:
	lds		p2x, r6s
	lds		p2xh, r7s
	cp		p2x, px
	cpc		p2xh, py
	brcc	pbr23
	ret


cbar:	; filled box

	ldi		i, 0xff
	movw	acc, p1x
	sub		acc, p2x
	sbc		acch, p2xh
	brcc	cbr10
	eor		acc, i
	eor		acch, i
	inc		acc
	brne	cbr10
	inc		acch
cbr10:
	mov		py, p1y 
	sub		py, p2y
	brcc	cbr11
	eor		py, i
	inc		py
cbr11:	
	ldi		i, 0x00
	sub		acc, py
	sbc		acch, i

	brcs	cbr20				; optimize using vertical lines

	cp		p1y, p2y			; optimize using horizontal lines
	brcc	cbr12
	mov		py, p1y
	mov		px, p2y
	jmp		cbr2
cbr12:
	mov		py, p2y
	mov		px, p1y

cbr2:
	cp		p1x, p2x
	cpc		p1xh, p2xh
	brcc	cbr3

	sts		r2s, p1x
	sts		r3s, p1xh
	sts		r6s, p2x
	sts		r7s, p2xh
	jmp		cbr4
cbr3:
	sts		r2s, p2x
	sts		r3s, p2xh
	sts		r6s, p1x
	sts		r7s, p1xh
cbr4:
	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p2x, r6s
	lds		p2xh, r7s
	mov		p1y, py
	mov		p2y, py
	call	chorz1
	inc		py
	cp		px, py
	brcc	cbr4
	ret

cbr20:
	sts		r4s, p1y
	sts		r5s, p2y

	cp		p1x, p2x
	cpc		p1xh, p2xh
	brcc	cbr21

	sts		r6s, p2x
	sts		r7s, p2xh
	movw	px, p1x
	jmp		cbr22

cbr21:
	sts		r6s, p1x
	sts		r7s, p1xh
	movw	px, p2x

cbr22:
	cp		p1y, p2y
	brcc	cbr23
	lds		p1y, r5s
	lds		p2y, r4s
cbr23:
	movw	p1x, px
	movw	p2x, px
	lds		p1y, r4s
	lds		p2y, r5s
	call	cvert1
	inc		px
	brne	cbr24
	inc		py
cbr24:
	lds		p2x, r6s
	lds		p2xh, r7s
	cp		p2x, px
	cpc		p2xh, py
	brcc	cbr23
	ret



circle:   ; center at p1, radius p2x, p2xh
	tst		p2xh
	brne	cir1
	tst		p2x
	brne	cir1
	jmp		pset				; radius 0 - set point only

cir1:
	sts		r2s, p1x
	sts		r3s, p1xh
	sts		r4s, p1y
	sts		r6s, p2x
	sts		r7s, p2xh			; save center point

	ldi		i, 0x01
	ldi		j, 0x00
	movw	px, i				; px,py = dx
	movw	acc, i				; acc = f (need to save during pset's)
	sub		acc, p2x
	sbc		acch, p2xh			; f = 1 - r
	movw	k, p2x				; k=dy
	lsl		k
	rol		l					; dy = r * 2
	ldi		i, 0xff				; 
	eor		k, i
	eor		l, i
	inc		k
	brne	cir2
	inc		l					; dy = -2 * r
cir2:
	clr		zl
	clr		zh					; x = 0 
	movw	yl, p2x				; y = r

cir3:
	cp		zl, yl
	cpc		zh, yh
	brmi	cir35				; done
	jmp		cir9

cir35:
	ldi		i, 0x02
	ldi		j, 0x00				; 2

	tst		acch
	brmi	cir4
	sbiw	yl, 0x01			; y=y-1
	add		k, i
	adc		k, j				; dy=dy+2
	add		acc, k
	adc		acch, l				; f=f+dy

cir4:
	adiw	zl, 0x01			; x=x+1
	add		px, i
	adc		py, j				; dx=dx+2
	add		acc, px
	adc		acch, py			; f=f+dx

	sts		r30s, zl
	sts		r31s, zh
	sts		r0s, acc
	sts		r1s, acch

	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s

	add		p1x, zl
	adc		p1xh, zh
	add		p1y, yl
	call	pset

	lds		p1y, r4s
	sub		p1y, yl
	call	pset

	lds		zh, r31s
	lds		zl, r30s
	lds		p1x, r2s
	lds		p1xh, r3s
	sub		p1x, zl
	sbc		p1xh, zh
	call	pset

	lds		p1y, r4s
	add		p1y, yl
	call	pset

	lds		zl, r30s
	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	sub		p1x, yl
	sbc		p1xh, yh
	add		p1y, zl
	call	pset

	lds		zl, r30s
	lds		p1y, r4s
	sub		p1y, zl
	call	pset

	lds		p1x, r2s
	lds		p1xh, r3s
	add		p1x, yl
	adc		p1xh, yh
	call	pset	

	lds		zl, r30s
	lds		p1y, r4s
	add		p1y, zl
	call	pset

	lds		acch, r1s
	lds		acc, r0s
	lds		zh, r31s
	lds		zl, r30s
	jmp		cir3

cir9:
	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	sub		p1y, p2x
	call	pset

	lds		p1y, r4s
	add		p1y, p2x
	call	pset

	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	add		p1x, p2x
	adc		p1xh, p2xh
	call	pset

	lds		p1x, r2s
	lds		p1xh, r3s
	sub		p1x, p2x
	sbc		p1xh, p2xh
	call	pset
	ret

ccircle:   ; center at p1, radius p2x, p2xh - erase circle
	tst		p2xh
	brne	ccir1
	tst		p2x
	brne	ccir1
	jmp		pclr				; radius 0 - set point only

ccir1:
	sts		r2s, p1x
	sts		r3s, p1xh
	sts		r4s, p1y
	sts		r6s, p2x
	sts		r7s, p2xh			; save center point

	ldi		i, 0x01
	ldi		j, 0x00
	movw	px, i				; px,py = dx
	movw	acc, i				; acc = f (need to save during pset's)
	sub		acc, p2x
	sbc		acch, p2xh			; f = 1 - r
	movw	k, p2x				; k=dy
	lsl		k
	rol		l					; dy = r * 2
	ldi		i, 0xff				; 
	eor		k, i
	eor		l, i
	inc		k
	brne	ccir2
	inc		l					; dy = -2 * r
ccir2:
	clr		zl
	clr		zh					; x = 0 
	movw	yl, p2x				; y = r

ccir3:
	cp		zl, yl
	cpc		zh, yh
	brmi	ccir35				; done
	jmp		ccir9

ccir35:
	ldi		i, 0x02
	ldi		j, 0x00				; 2

	tst		acch
	brmi	ccir4
	sbiw	yl, 0x01			; y=y-1
	add		k, i
	adc		k, j				; dy=dy+2
	add		acc, k
	adc		acch, l				; f=f+dy

ccir4:
	adiw	zl, 0x01			; x=x+1
	add		px, i
	adc		py, j				; dx=dx+2
	add		acc, px
	adc		acch, py			; f=f+dx

	sts		r30s, zl
	sts		r31s, zh
	sts		r0s, acc
	sts		r1s, acch

	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s

	add		p1x, zl
	adc		p1xh, zh
	add		p1y, yl
	call	pclr

	lds		p1y, r4s
	sub		p1y, yl
	call	pclr

	lds		zh, r31s
	lds		zl, r30s
	lds		p1x, r2s
	lds		p1xh, r3s
	sub		p1x, zl
	sbc		p1xh, zh
	call	pclr

	lds		p1y, r4s
	add		p1y, yl
	call	pclr

	lds		zl, r30s
	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	sub		p1x, yl
	sbc		p1xh, yh
	add		p1y, zl
	call	pclr

	lds		zl, r30s
	lds		p1y, r4s
	sub		p1y, zl
	call	pclr

	lds		p1x, r2s
	lds		p1xh, r3s
	add		p1x, yl
	adc		p1xh, yh
	call	pclr	

	lds		zl, r30s
	lds		p1y, r4s
	add		p1y, zl
	call	pclr

	lds		acch, r1s
	lds		acc, r0s
	lds		zh, r31s
	lds		zl, r30s
	jmp		ccir3

ccir9:
	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	sub		p1y, p2x
	call	pclr

	lds		p1y, r4s
	add		p1y, p2x
	call	pclr

	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	add		p1x, p2x
	adc		p1xh, p2xh
	call	pclr

	lds		p1x, r2s
	lds		p1xh, r3s
	sub		p1x, p2x
	sbc		p1xh, p2xh
	call	pclr
	ret



fcircle:   ; center at p1, radius p2x, p2xh filled
	tst		p2xh
	brne	fcir1
	tst		p2x
	brne	fcir1
	jmp		pset				; radius 0 - set point only

fcir1:
	sts		r2s, p1x
	sts		r3s, p1xh
	sts		r4s, p1y			; save center point
	sts		r6s, p2x
	sts		r7s, p2xh			; save radius

	ldi		i, 0x01
	ldi		j, 0x00
	movw	px, i				; px,py = dx
	movw	acc, i				; acc = f (need to save during pset's)
	sub		acc, p2x
	sbc		acch, p2xh			; f = 1 - r
	movw	k, p2x				; k=dy
	lsl		k
	rol		l					; dy = r * 2
	ldi		i, 0xff				; 
	eor		k, i
	eor		l, i
	inc		k
	brne	fcir2
	inc		l					; dy = -2 * r
fcir2:
	clr		zl
	clr		zh					; x = 0 
	movw	yl, p2x				; y = r

fcir3:
	cp		zl, yl
	cpc		zh, yh
	brmi	fcir35				; done
	jmp		fcir9

fcir35:
	ldi		i, 0x02
	ldi		j, 0x00				; 2

	tst		acch
	brmi	fcir4
	sbiw	yl, 0x01			; y=y-1
	add		k, i
	adc		k, j				; dy=dy+2
	add		acc, k
	adc		acch, l				; f=f+dy

fcir4:
	adiw	zl, 0x01			; x=x+1
	add		px, i
	adc		py, j				; dx=dx+2
	add		acc, px
	adc		acch, py			; f=f+dx

	sts		r30s, zl
	sts		r31s, zh
	sts		r0s, acc
	sts		r1s, acch

	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	add		p1x, zl
	adc		p1xh, zh
	movw	p2x, p1x
	mov		p2y, p1y
	sub		p1y, yl
	add		p2y, yl
	call	vert1

	lds		zh, r31s
	lds		zl, r30s
	lds		acc, r0s
	lds		acch, r1s
	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	sub		p1x, zl
	sbc		p1xh, zh
	movw	p2x, p1x
	mov		p2y, p1y
	sub		p1y, yl
	add		p2y, yl
	call	vert1


	lds		zl, r30s
	lds		p1x, r2s
	lds		acc, r0s
	lds		acch, r1s
	lds		p1xh, r3s
	lds		p1y, r4s
	sub		p1x, yl
	sbc		p1xh, yh
	movw	p2x, p1x
	mov		p2y, p1y
	sub		p1y, zl
	add		p2y, zl
	call	vert1

	lds		zl, r30s
	lds		p1x, r2s
	lds		acc, r0s
	lds		acch, r1s
	lds		p1xh, r3s
	lds		p1y, r4s
	add		p1x, yl
	adc		p1xh, yh
	movw	p2x, p1x
	mov		p2y, p1y
	sub		p1y, zl
	add		p2y, zl
	call	vert1

	lds		zh, r31s
	lds		zl, r30s
	lds		acc, r0s
	lds		acch, r1s

	jmp		fcir3

fcir9:
	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	movw	p2x, p1x
	mov		p2y, p1y
	lds		i, r6s
	sub		p1y, i
	add		p2y, i
	call	vert1
	ret

cfcircle:   ; center at p1, radius p2x, p2xh filled
	tst		p2xh
	brne	cfcir1
	tst		p2x
	brne	cfcir1
	jmp		pclr				; radius 0 - set point only

cfcir1:
	sts		r2s, p1x
	sts		r3s, p1xh
	sts		r4s, p1y			; save center point
	sts		r6s, p2x
	sts		r7s, p2xh			; save radius

	ldi		i, 0x01
	ldi		j, 0x00
	movw	px, i				; px,py = dx
	movw	acc, i				; acc = f (need to save during pset's)
	sub		acc, p2x
	sbc		acch, p2xh			; f = 1 - r
	movw	k, p2x				; k=dy
	lsl		k
	rol		l					; dy = r * 2
	ldi		i, 0xff				; 
	eor		k, i
	eor		l, i
	inc		k
	brne	cfcir2
	inc		l					; dy = -2 * r
cfcir2:
	clr		zl
	clr		zh					; x = 0 
	movw	yl, p2x				; y = r

cfcir3:
	cp		zl, yl
	cpc		zh, yh
	brmi	cfcir35				; done
	jmp		cfcir9

cfcir35:
	ldi		i, 0x02
	ldi		j, 0x00				; 2

	tst		acch
	brmi	cfcir4
	sbiw	yl, 0x01			; y=y-1
	add		k, i
	adc		k, j				; dy=dy+2
	add		acc, k
	adc		acch, l				; f=f+dy

cfcir4:
	adiw	zl, 0x01			; x=x+1
	add		px, i
	adc		py, j				; dx=dx+2
	add		acc, px
	adc		acch, py			; f=f+dx

	sts		r30s, zl
	sts		r31s, zh
	sts		r0s, acc
	sts		r1s, acch

	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	add		p1x, zl
	adc		p1xh, zh
	movw	p2x, p1x
	mov		p2y, p1y
	sub		p1y, yl
	add		p2y, yl
	call	cvert1

	lds		zh, r31s
	lds		zl, r30s
	lds		acc, r0s
	lds		acch, r1s
	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	sub		p1x, zl
	sbc		p1xh, zh
	movw	p2x, p1x
	mov		p2y, p1y
	sub		p1y, yl
	add		p2y, yl
	call	cvert1


	lds		zl, r30s
	lds		p1x, r2s
	lds		acc, r0s
	lds		acch, r1s
	lds		p1xh, r3s
	lds		p1y, r4s
	sub		p1x, yl
	sbc		p1xh, yh
	movw	p2x, p1x
	mov		p2y, p1y
	sub		p1y, zl
	add		p2y, zl
	call	cvert1

	lds		zl, r30s
	lds		p1x, r2s
	lds		acc, r0s
	lds		acch, r1s
	lds		p1xh, r3s
	lds		p1y, r4s
	add		p1x, yl
	adc		p1xh, yh
	movw	p2x, p1x
	mov		p2y, p1y
	sub		p1y, zl
	add		p2y, zl
	call	cvert1

	lds		zh, r31s
	lds		zl, r30s
	lds		acc, r0s
	lds		acch, r1s

	jmp		cfcir3

cfcir9:
	lds		p1x, r2s
	lds		p1xh, r3s
	lds		p1y, r4s
	movw	p2x, p1x
	mov		p2y, p1y
	lds		i, r6s
	sub		p1y, i
	add		p2y, i
	call	cvert1
	ret

.cseg

bstable:
	.db		0x80, 0x40
	.db		0x20, 0x10
	.db		0x08, 0x04
	.db		0x02, 0x01


bctable:
	.db		0x7F, 0xBF
	.db		0xDF, 0xEF
	.db		0xF7, 0xFB
	.db		0xFD, 0xFE


