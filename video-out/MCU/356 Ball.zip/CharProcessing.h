/*
 * CharProcessing.h
 *
 *  Created on: Nov 10, 2019
 *      Author: Stuart
 */

#ifndef CHARPROCESSING_H_
#define CHARPROCESSING_H_

extern uint8_t DisplayMem[] ;

extern uint8_t DisplayMode ;
extern uint32_t XferSize ;		// 75 or 35 bytes to DMA. Same as CharsPerRow for now.
extern uint8_t CharsPerRow ; 	// 75 or 35 chars per row
extern uint8_t CharRowsPerScreen ;
extern uint16_t CurrentTopOfScan ;  // Index into display memory for first line to be displayed after vsync.
extern uint16_t TopOfScanRow ;

void WriteCharAtCursor(uint8_t) ;
void InitializeDisplayMemory(void) ;
void DashLines(void) ;
void AtoZtoCursor(void) ;
void SetCursor(uint16_t, uint16_t) ;
void ZeroTo9toCursor(void) ;
void AllCharsToCursor() ;
void UnderlineCursor(uint8_t) ;
void ProcessNewChar(uint8_t) ;


#endif /* CHARPROCESSING_H_ */
