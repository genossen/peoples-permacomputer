/* Composite video generator, just an experiment to exercise the DMA, timer, and other
 * interactions.  TM4C1233H6PM.  Input crystal 12 MHz.  CPU clock 80 MHz.
 *
 * This version uses uDMA to drive 7-bit SPI channel for video dots.  Timer0 B generates
 * horizontal sync and an interrupt, which kicks off the DMA of live video.
 *
 *
 * Intended for 7x9 character generator, 10 MHz dot clock, 60 Hz vertical interval.
 * Horiz line timing: 15750 Hz (63.5 uS):
 * 75 live characters, 1.5 uS black, 4.7 uS sync, 4.7 uS back porch
 * Vertical is 262 lines, 22 live char lines (22 x 10 dot rows) then 24 blank/sync dot rows.
 * Note that live live space is componsed of 22 9-line char blocks and one blank row for
 * a total of 22x10.
 * Display memory uses 18K of available 32K memory.
 * PA7 selects display mode; 1 = 75x24, 0 = 35 x 12.
 * 75x24 is implemented by using a dot clock of 10 MHz, 35x12 uses 5 MHz.
 * For 35x11, vertical is implemented by sending each horizontal row of dots
 * twice, so a 9-high char becomes 18 high.  This makes vertical the same
 * ratio as horizontal.
 *
 * For scrolling, after the vertical blanking interval, the display starts at an offset.
 * So if text input reaches the end of the last line on the display, the TOP line
 * is blanked and display starts at the next line.  So horiz sync interrupt has to
 * know where to start the next line.
 *
 * Special characters:
 * Carriage return: 0x0D
 * Line feed: 0x0A
 * Backspace: 08
 */

// Port usage:
// Port A 0:1 is debug/download serial port,
//      PA2 is dot clock (unconnected but reserved)
//      PA3 is unused (SSI0 frame signal)
//      PA4 is NC but reserved (SSI0 Rx)
//      PA5 is dot output (SSI0Tx)
//		PA6 is spare mode switch
//		PA7 is display mode; 1 = 75x24, 0 = 35x16.
// Port B: PB4 is SSI2clk, PB7 is SSI2Tx, blanking output
//			PB3 is vertical trigger for oscilloscope.
// Port C
// Port D: PD0 is SSI1CLK, PD3 is SSI1Tx
// Port E
// Port F PF2 is download enable jumper, PF3 is diag LED, PF4 is HB LED.
// Port G
// Port H
// Port J:
// Port K:


// Code is compiled using TI Code Composer studio.  To make it compile,
// select the target device in the project setup, and then add the following
// to the linker search path (substitue appropriate version, of course):
// C:\ti\TivaWare_C_Series-2.1.4.178\driverlib\ccs\debug\driverlib.lib
// C:\ti\TivaWare_C_Series-2.1.4.178\grlib\ccs\debug\grlib.lib
// To compiler search path, add:
// c:\ti\TivaWare_C_Series-2.1.4.178
// To generate binary output file that can be sent to serial port using
// TI LMflash utility, add following to Properties - CCS Build - Steps, (all has to be on one line):
// "${CCE_INSTALL_ROOT}/utils/tiobj2bin/tiobj2bin" "${BuildArtifactFileName}" "${BuildArtifactFileBaseName}.bin" "${CG_TOOL_ROOT}/bin/armofd" "${CG_TOOL_ROOT}/bin/armhex" "${CCE_INSTALL_ROOT}/utils/tiobj2bin/mkhex4bin"

#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/timer.h"
#include "grlib/grlib.h"
#include "driverlib/uart.h"
#include "driverlib/ssi.h"
#include "driverlib/pin_map.h"
#include "inc/tm4c1233H6PM.h"
#include "driverlib/interrupt.h"
#include "driverlib/systick.h"
#include "driverlib/uDMA.h"
#include "inc/hw_nvic.h"

#include "CharProcessing.h"


//Make PF2 boot
// Value to boot config register; select port PF2, low
// enables ROM bootloader. Key = 1, debug enabled.
//                         Reserved     PF2     Key   DBG
#define BootConfigValue (0x7FFF0000 + 0xA800  + 0x10 + 2)


#define TARGET_IS_TM4C123_RB1

// Heartbeat and diagnostic LEDs.
#define HBLEDon MAP_GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4, 0)
#define HBLEDoff MAP_GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4, GPIO_PIN_4)
#define DiagLEDon MAP_GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0)
#define DiagLEDoff MAP_GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, GPIO_PIN_3)

// vertical trigger
#define VtrigLo MAP_GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_3, 0)
#define VtrigHi MAP_GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_3, GPIO_PIN_3)

#define TicksPerSec 1000


uint8_t SysTickIntFlag = 0 ;
uint16_t OneshotTicker = 0 ;

uint16_t ScanLines = 0 ;        // Count of scan lines, 0-261, to define full vertical space.
uint16_t DisplayIndex = 0 ;     // Start of current scan row (not character).  This is byte index into display mem.
uint8_t Vflag = 0 ;				// Set to 1 when in vert mode.


int8_t ScanOddEven = 0 ;		// Odd/even scan row for 35 char.


// DMA config structure. Primary is live scan, alternate is blanking area.
#pragma DATA_ALIGN(DMAconfig, 1024) ;
uint8_t DMAconfig[1024] ;

// ISR for SysTick timer, just incr ticker count.
void SysTickISR()
{
    SysTickIntFlag ++ ;
}

void OStrigger()
{
    DiagLEDon ;
    OneshotTicker = 250 ;
}


// Timer ISR occurs when timer 0 (sync) completes.
// generates blanking and activates DMA for live scan.
// Blanking is 6 chars for about 4.2 uSec.  At time of this interrupt,
// the SSI1 FIFO is empty, so we can push 6 bytes of blanking (0) into
// the FIFO and then start the DMA transfer of the 75 char live scan
// portion.
// Note that in 35-char mode, each scan line is sent twice, making chars twice as high,
// while lower SSI clock rates makes them twice as wide.
void TimerISR()
{
	uint8_t iStatus ;

	// 6 blanking outputs, back porch of horiz or just blanking during vertical
	// For Display mode = 0 (35 char) only need 3 blanking outputs because
	// dot clock is half the 75 char-per-line rate.
	HWREG(SSI1_BASE + 0x08) = 0 ;
	HWREG(SSI1_BASE + 0x08) = 0 ;
	HWREG(SSI1_BASE + 0x08) = 0 ;
	HWREG(SSI1_BASE + 0x08) = 0 ;
	//
	// Need double number of blanking lines for 75-char mode because each is half as tall.
	if (DisplayMode)
	{
		HWREG(SSI1_BASE + 0x08) = 0 ;
		HWREG(SSI1_BASE + 0x08) = 0 ;
		HWREG(SSI1_BASE + 0x08) = 0 ;
		HWREG(SSI1_BASE + 0x08) = 0 ;
	}

	// Clear the interrupt
	iStatus = GPIOIntStatus(GPIO_PORTB_BASE,true);
	GPIOIntClear(GPIO_PORTB_BASE, iStatus);

	ScanLines += 1 ;

	// Scan lines 0-15 are blanking after vertical retrace. Need one more scan line at top
	// and at bottom for 16:9 instead of 4:3.
	// For scan lines 12-229, live scan area.  Scan lines 240-261 are vblank/vsync area.
	if ((216 > ScanLines) && (ScanLines > 15))
	{
        // Lines 0-239, restart DMA at next dot row.
		if (DisplayMode) DisplayIndex += 75 ;        // increment to next dot row.
		else
		{
			if (ScanOddEven)
			{
				ScanOddEven = 0 ;
				DisplayIndex += 75 ;
			}
			else ScanOddEven = 1 ;
		}

        // For scrolling display, need to check for DisplayIndex at end of display and
        // reset to 0.
		if (DisplayIndex > CharRowsPerScreen * 750)
		{
		    DisplayIndex = 0 ;
		    ScanOddEven = 0 ;
		}

        uDMAChannelTransferSet(UDMA_PRI_SELECT | UDMA_CHANNEL_SSI1TX,
             UDMA_MODE_BASIC, &DisplayMem[DisplayIndex], (void*) (SSI1_BASE + 8), XferSize) ;

        uDMAChannelEnable(UDMA_CHANNEL_SSI1TX) ;
	}

	else if (262 > ScanLines)
	{
	    // Starting at scan line 245 (6 scans into the vertical interval), set sync width to 4700.
	    // This generates a wider but serrated sync pulse to reset vertical.  This runs for 3
	    // lines to get vertical resync started.  Note that in this ISR, can't set the new
		// duty cycle directly because it results in a short on-off-on pulse on sync.  So set
		// Vflag, and main loop changes duty cycle when timer value drops below the new duty cycle
		// value, so the sync width will change on the NEXT load, making a full-width, glitch-free
		// sync pulse.
	    if (245 == ScanLines) Vflag = 1 ;
	    if (248 == ScanLines) TimerMatchSet(TIMER0_BASE, TIMER_B, 376);    // Back to 4.7 us sync
	    VtrigHi ;
	}

	// End of vertical interval, end of entire screen, reset to top.  Note that since we scroll
	// the display, the first displayed line isn't necessarily line 0, but is the first line
	// of the row defined by TopOfScanRow.
	else
	{
	    ScanLines = 0 ;     // Restart scan count at top of display
	    DisplayIndex = TopOfScanRow * 750 ;
	    VtrigLo ;
	    ScanOddEven = 0 ;
	}

}

void Setup(void)
{

    volatile uint32_t TempValue ;

    // Enable external 12 MHz crystal, PLL it up to 80 MHz
    MAP_SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL | SYSCTL_XTAL_12MHZ | SYSCTL_OSC_MAIN ) ;

    //Read BOOTCFG value.  If it is already configured, then we're done.
    // For uninitialized register, port/pin values will be 1 (0xFC00)
    if (0xFC00 == (FLASH_BOOTCFG_R & 0xFC00))
    {
        // Port/Pin bits are 1, so register has not yet been initialized.
        FLASH_FMA_R = 0x75100000;
        FLASH_FMD_R = BootConfigValue;
        FLASH_FMC_R = 0xA4420009;       // Write key and commit bit.
        while(FLASH_FMC_R & FLASH_FMC_COMT)
        {
        }
    }

    // Enable all ports
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA) ;
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB) ;
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC) ;
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD) ;
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE) ;
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF) ;
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_UDMA) ;
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0) ;

    // Loop until port F is ready.  F is the last one enabled, so when it's
    // ready, all the others should be ready as well.
    while(!MAP_SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF))
    {
    }

    // unlock PF0 for use as I/O
    GPIO_PORTF_LOCK_R = 0x4C4F434B ;
    GPIO_PORTF_CR_R   |= 0x1 ;

    // Unlock PD7 for use as I/O
    GPIO_PORTD_LOCK_R = GPIO_LOCK_KEY;
    GPIO_PORTD_CR_R |= GPIO_PIN_7;

    // **************** Port F initialization, LEDs. ***************************
    // PF3, 4 are LEDs is boot enable, all others outputs
     MAP_GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE,  GPIO_PIN_3 | GPIO_PIN_4 ) ;
     HBLEDon ;
     DiagLEDoff ;



    // Enable peripherals
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART1) ;
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_SSI1);


    // Loop until last SSI enable completes
    while(!MAP_SysCtlPeripheralReady(SYSCTL_PERIPH_SSI1))
    {
    }


    // Set GPIO B0/B1 as UART for external host comms.
    MAP_GPIOPinTypeUART(GPIO_PORTB_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    GPIOPinConfigure(GPIO_PB0_U1RX) ;
    GPIOPinConfigure(GPIO_PB1_U1TX) ;

    // Configure the UART for 9600, n, 8, 1
    // This version uses actual CPU frequency
    MAP_UARTConfigSetExpClk(UART1_BASE, SysCtlClockGet(), 9600,
                            (UART_CONFIG_PAR_NONE | UART_CONFIG_STOP_ONE |
                            UART_CONFIG_WLEN_8));


    // 2-position DIP switch for mode is on PA6, PA7.
    GPIOPinTypeGPIOInput(GPIO_PORTA_BASE, GPIO_PIN_6 | GPIO_PIN_7) ;

    // Read display mode bit from DIP switch.
    DisplayMode = MAP_GPIOPinRead(GPIO_PORTA_BASE, GPIO_PIN_7) ;
    if (DisplayMode)
    {
    	XferSize = 75 ;
    	CharsPerRow = 75 ;
    	CharRowsPerScreen = 20 ;
    }
    else
    {
    	XferSize = 35 ;
    	CharsPerRow = 35 ;
    	CharRowsPerScreen = 10 ;
    }

    // Configure PD0 and PD7 as SSI1 master. 7 data bits, 10 MB/s data rate.  SSI1 is blanking output.
    MAP_GPIOPinTypeSSI(GPIO_PORTD_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_3) ;

    // Configure PD0 and PD7 as SSI 0, using maps in pin_map.h.
    MAP_GPIOPinConfigure(GPIO_PD0_SSI1CLK) ;
    MAP_GPIOPinConfigure(GPIO_PD1_SSI1FSS) ;
    MAP_GPIOPinConfigure(GPIO_PD3_SSI1TX) ;

    // Configure SSI1 for master,7 bits per transfer. 10MB/S or 5 MB/S depending on mode.
    if (DisplayMode) SSIConfigSetExpClk(SSI1_BASE, SysCtlClockGet(), SSI_FRF_TI, SSI_MODE_MASTER, 10000000, 7);
    else SSIConfigSetExpClk(SSI1_BASE, SysCtlClockGet(), SSI_FRF_TI, SSI_MODE_MASTER, 5000000, 7);

    SSIEnable(SSI1_BASE);

    // Set up timer B as split timer, 16-bit PWM
    TimerConfigure(TIMER0_BASE, TIMER_CFG_SPLIT_PAIR|TIMER_CFG_B_PWM);

    // Configure timer for 4.7 us sync output every 63 us.
    TimerLoadSet(TIMER0_BASE, TIMER_B, 5080);   // 15748 Hz

    TimerMatchSet(TIMER0_BASE, TIMER_B, 376);    // 4.7 us sync

    TimerEnable(TIMER0_BASE, TIMER_B);
    MAP_GPIOPinConfigure(GPIO_PB7_T0CCP1) ;
    GPIOPinTypeTimer(GPIO_PORTB_BASE, GPIO_PIN_7);

    // Set up PB6 as input for interrupt from PWM output (which is on PB7).
    GPIOIntRegister(GPIO_PORTB_BASE, TimerISR) ;
    GPIOPinTypeGPIOInput(GPIO_PORTB_BASE, GPIO_PIN_6) ;
    GPIOIntTypeSet(GPIO_PORTB_BASE, GPIO_PIN_6, GPIO_RISING_EDGE) ;
    GPIOIntEnable(GPIO_PORTB_BASE, GPIO_INT_PIN_6) ;

    // Vertical trigger output, just for triggering a scope.
    MAP_GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE,  GPIO_PIN_3 ) ;

    // Set Dot output (PD3) and sync output (PB7) to 8ma drive for driving composite video.
    MAP_GPIOPadConfigSet(GPIO_PORTB_BASE, GPIO_PIN_7, GPIO_STRENGTH_8MA, GPIO_PIN_TYPE_STD) ;
    MAP_GPIOPadConfigSet(GPIO_PORTD_BASE, GPIO_PIN_3, GPIO_STRENGTH_8MA, GPIO_PIN_TYPE_STD) ;

   // Set up SysTick timer as system timer.  Set to 80MHZ/80000, or 1000 Hz.
    // Note this version doesn't use systick interrupt, it polls the timer.
   //SysTickIntRegister(SysTickISR);
   MAP_SysTickPeriodSet(80000);
   MAP_IntMasterEnable();
   //MAP_SysTickIntEnable();
   MAP_SysTickEnable();

   // Configure UDMA for ping-pong on SSI0 between active memory and blanking memory.
   uDMAEnable() ;
   uDMAControlBaseSet(&DMAconfig[0]) ;

   uDMAChannelControlSet(UDMA_PRI_SELECT | UDMA_CHANNEL_SSI1TX,
		   UDMA_SIZE_8 | UDMA_SRC_INC_8 | UDMA_DST_INC_NONE | UDMA_ARB_1) ;

   uDMAChannelTransferSet(UDMA_PRI_SELECT | UDMA_CHANNEL_SSI1TX,
		   UDMA_MODE_BASIC, &DisplayMem[0], (void*) (SSI1_BASE + 8), XferSize) ;

   uDMAChannelEnable(UDMA_CHANNEL_SSI1TX) ;

   SSIDMAEnable(SSI1_BASE, SSI_DMA_TX) ;

}


int main(void)
{
	uint16_t i, j ;
    uint16_t ticker = 0 ;        // LED timing ticker.
    uint8_t ByteFromUART ;


    Setup() ;

    // Empty UART of any pending (and probably invalid) char.
    while (MAP_UARTCharsAvail(UART1_BASE))
    {
    	ByteFromUART = (uint8_t) (0xFF & MAP_UARTCharGet(UART1_BASE)) ;
    }

    InitializeDisplayMemory() ;

    //DashLines() ;
    SetCursor(0, 0) ; 		// Set to row one for now.
    //AtoZtoCursor() ;
    //SetCursor(9, 0) ;
    //ZeroTo9toCursor() ;
    //AllCharsToCursor() ;

    // Test only; fill screen with A-K, should scroll off screen on last line.
    //for (i = 0x41; i < 0x4A; i++)
    //{
    //	for(j = 0; j < 35; j++) WriteCharAtCursor((uint8_t) i) ;
    //}


    while (1)
    {

        // Manually poll Systick control reg for rollover.  So systick doesn't affect v timing.
        if (HWREG(NVIC_ST_CTRL) & 0x10000)
        // sys tick occurred, blink LED & do 1 sec stuff.
        //if (SysTickIntFlag)
        {
            SysTickIntFlag = 0 ;

            //MAP_TimerIntClear(TIMER0_BASE, 1) ;   // Clear timer 0 flag.
            //if (TickFlagForLCD < 255) TickFlagForLCD += 1 ; // Increment tick flag, stick at 0xFF.
            ticker ++ ;
            if (TicksPerSec/2 == ticker)
            {
            	HBLEDon;
            	UnderlineCursor(0x7E) ;
            }
            if (TicksPerSec == ticker)
            {
                HBLEDoff;
                ticker = 0 ;
                UnderlineCursor(0) ;

            }
            if (OneshotTicker)
            {
                OneshotTicker -= 1 ;
                if (OneshotTicker == 0) DiagLEDoff ;
                else DiagLEDon ;
            }
        }

        // If timer ISR set Vflag, we're in vertical sync/blanking mode.  Need to change
        // PWM timing to get longer vertical sync pulse.  But can't do this in ISR
        // because it will cause a very fast sync on -sync off - sync on cycle because the PWM
        // responds immediately to the period change.  So if Vflag is set, wait for the
        // PWM timer count to be less than match value, THEN change the PWM ducy cycle value.
        if (Vflag)
        {
        	if (TimerValueGet(TIMER0_BASE, TIMER_B) < 4700)
        	{
        		TimerMatchSet(TIMER0_BASE, TIMER_B, 4700);    // 58 us sync
        		Vflag = 0 ;
        	}
        }
    	// If char received from host, process it.
    	if (MAP_UARTCharsAvail(UART1_BASE))
    	{
    		// Read UART, which is 32-bit word, convert to uint8 ;
    		ByteFromUART = (uint8_t) (0xFF & MAP_UARTCharGet(UART1_BASE)) ;
    		ProcessNewChar(ByteFromUART) ;
    	}

    	// Initial HW debug - send continuse "A" if transmitter ready.
    	//if (MAP_UARTSpaceAvail(UART1_BASE)) MAP_UARTCharPut(UART1_BASE, 0x41) ;

    }

}
